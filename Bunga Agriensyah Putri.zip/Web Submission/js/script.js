(function(){
    var loki = document.getElementById('jumbotron-h1');
    window.onscroll = (function(){
        var val = scrollY;
        console.log(val)
        loki.style.transform = "translateY(" + val/1.8 + "px)";
        if (val>420) {
            loki.style.transform = "translateY(210px)";
        }})
}());


const txtElement = ['Information System Student Major'];
let count = 0;
let txtIndex = 0;
let currentTxt = '';
let words = '';


(function ngetik(){

	if(count == txtElement.length){
		count = 0;
	}

	currentTxt = txtElement[count];

	words = currentTxt.slice(0, ++txtIndex);
	document.querySelector('.typingcolor').textContent = words;

	if(words.length == currentTxt.length){
		count++;
        
        txtIndex = 0;s
	}

	setTimeout(ngetik, 50);

})();


var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  setTimeout(showSlides, 3000); 
}
